public class BankAccount
{
    double balance; 
}